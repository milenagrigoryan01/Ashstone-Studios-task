const header = document.querySelector('#header');
document.addEventListener('scroll', () => {
    var scroll_position = window.scrollY;
    if (scroll_position < 200) {
        header.style.position = 'inherit';
    }
    else{
        header.style.position = 'fixed';
        header.style.top = '0';
        header.style.right = '0';
        header.style.left = '0';
        header.style.transition = '0.5s';
    }
});

(() => {
    const hamburger = document.getElementById("hamburger");
    const menu = document.getElementById("overlay");
    let closed = true;

    const change = () => {
        if (closed) {
            hamburger.classList.add("open");
            menu.classList.add("menu");
        } else {
            hamburger.classList.remove("open");
            menu.classList.remove("menu");
        }
        closed = !closed;
    };

    hamburger.addEventListener("click", change);
})();
